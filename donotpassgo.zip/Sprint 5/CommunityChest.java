
public class CommunityChest extends Square {
	
	CommunityChest () {
		super("Community Chest");
		return;
	}
	
}

