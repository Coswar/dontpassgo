
public interface DiceAPI {
	
	public int[] getDice ();
	public int getTotal ();
	public boolean isDouble ();
	public String toString ();

}
