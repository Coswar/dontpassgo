
public class Square {

	private String name;
	
	Square (String name) {
		this.name = name;
		return;
	}
	
	public String getName () {
		return name;
	}
	
	public String toString () {
		return name;
	}
	
}
