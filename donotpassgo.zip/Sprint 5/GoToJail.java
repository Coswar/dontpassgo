
public class GoToJail extends Square {
	
	GoToJail () {
		super("Go To Jail");
		return;
	}

}
