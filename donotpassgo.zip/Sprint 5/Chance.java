
public class Chance extends Square {
	
	Chance () {
		super("Chance");
		return;
	}
	
}

